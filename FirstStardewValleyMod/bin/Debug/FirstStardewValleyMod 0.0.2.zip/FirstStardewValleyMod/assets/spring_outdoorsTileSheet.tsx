<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="2020.11.25" name="spring_outdoorsTileSheet" tilewidth="16" tileheight="16" tilecount="1975" columns="25">
 <image source="../../../../../../../Program Files (x86)/Steam/steamapps/common/Stardew Valley/Content (unpacked)/Maps/spring_outdoorsTileSheet.png" width="400" height="1264"/>
</tileset>
